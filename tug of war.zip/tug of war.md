```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
```


```python
file="C:/Users/preri/Downloads/Students Social Media Addiction.csv"
df=pd.read_csv(file)
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Student_ID</th>
      <th>Age</th>
      <th>Gender</th>
      <th>Academic_Level</th>
      <th>Country</th>
      <th>Avg_Daily_Usage_Hours</th>
      <th>Most_Used_Platform</th>
      <th>Affects_Academic_Performance</th>
      <th>Sleep_Hours_Per_Night</th>
      <th>Mental_Health_Score</th>
      <th>Relationship_Status</th>
      <th>Conflicts_Over_Social_Media</th>
      <th>Addicted_Score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>19</td>
      <td>Female</td>
      <td>Undergraduate</td>
      <td>Bangladesh</td>
      <td>5.2</td>
      <td>Instagram</td>
      <td>Yes</td>
      <td>6.5</td>
      <td>6</td>
      <td>In Relationship</td>
      <td>3</td>
      <td>8</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>22</td>
      <td>Male</td>
      <td>Graduate</td>
      <td>India</td>
      <td>2.1</td>
      <td>Twitter</td>
      <td>No</td>
      <td>7.5</td>
      <td>8</td>
      <td>Single</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>20</td>
      <td>Female</td>
      <td>Undergraduate</td>
      <td>USA</td>
      <td>6.0</td>
      <td>TikTok</td>
      <td>Yes</td>
      <td>5.0</td>
      <td>5</td>
      <td>Complicated</td>
      <td>4</td>
      <td>9</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>18</td>
      <td>Male</td>
      <td>High School</td>
      <td>UK</td>
      <td>3.0</td>
      <td>YouTube</td>
      <td>No</td>
      <td>7.0</td>
      <td>7</td>
      <td>Single</td>
      <td>1</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>21</td>
      <td>Male</td>
      <td>Graduate</td>
      <td>Canada</td>
      <td>4.5</td>
      <td>Facebook</td>
      <td>Yes</td>
      <td>6.0</td>
      <td>6</td>
      <td>In Relationship</td>
      <td>2</td>
      <td>7</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>700</th>
      <td>701</td>
      <td>20</td>
      <td>Female</td>
      <td>Undergraduate</td>
      <td>Italy</td>
      <td>4.7</td>
      <td>TikTok</td>
      <td>No</td>
      <td>7.2</td>
      <td>7</td>
      <td>In Relationship</td>
      <td>2</td>
      <td>5</td>
    </tr>
    <tr>
      <th>701</th>
      <td>702</td>
      <td>23</td>
      <td>Male</td>
      <td>Graduate</td>
      <td>Russia</td>
      <td>6.8</td>
      <td>Instagram</td>
      <td>Yes</td>
      <td>5.9</td>
      <td>4</td>
      <td>Single</td>
      <td>5</td>
      <td>9</td>
    </tr>
    <tr>
      <th>702</th>
      <td>703</td>
      <td>21</td>
      <td>Female</td>
      <td>Undergraduate</td>
      <td>China</td>
      <td>5.6</td>
      <td>WeChat</td>
      <td>Yes</td>
      <td>6.7</td>
      <td>6</td>
      <td>In Relationship</td>
      <td>3</td>
      <td>7</td>
    </tr>
    <tr>
      <th>703</th>
      <td>704</td>
      <td>24</td>
      <td>Male</td>
      <td>Graduate</td>
      <td>Japan</td>
      <td>4.3</td>
      <td>Twitter</td>
      <td>No</td>
      <td>7.5</td>
      <td>8</td>
      <td>Single</td>
      <td>2</td>
      <td>4</td>
    </tr>
    <tr>
      <th>704</th>
      <td>705</td>
      <td>19</td>
      <td>Female</td>
      <td>Undergraduate</td>
      <td>Poland</td>
      <td>6.2</td>
      <td>Facebook</td>
      <td>Yes</td>
      <td>6.3</td>
      <td>5</td>
      <td>Single</td>
      <td>4</td>
      <td>8</td>
    </tr>
  </tbody>
</table>
<p>705 rows × 13 columns</p>
</div>




```python
print(df.isnull().sum())
```

    Student_ID                      0
    Age                             0
    Gender                          0
    Academic_Level                  0
    Country                         0
    Avg_Daily_Usage_Hours           0
    Most_Used_Platform              0
    Affects_Academic_Performance    0
    Sleep_Hours_Per_Night           0
    Mental_Health_Score             0
    Relationship_Status             0
    Conflicts_Over_Social_Media     0
    Addicted_Score                  0
    dtype: int64
    


```python
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.metrics import mean_squared_error,r2_score
from sklearn.linear_model import LinearRegression
```


```python
X=df.drop('Addicted_Score',axis=1)
y=df['Addicted_Score']
```


```python
X=pd.get_dummies(X,drop_first=True)
```


```python
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2,random_state=42)
```


```python
model=LinearRegression()
model.fit(X_train,y_train)
```




<style>#sk-container-id-1 {color: black;background-color: white;}#sk-container-id-1 pre{padding: 0;}#sk-container-id-1 div.sk-toggleable {background-color: white;}#sk-container-id-1 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-1 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-1 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-1 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-1 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-1 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-1 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-1 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-1 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-1 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-1 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-1 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-1 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-1 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-1 div.sk-item {position: relative;z-index: 1;}#sk-container-id-1 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-1 div.sk-item::before, #sk-container-id-1 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-1 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-1 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-1 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-1 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-1 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-1 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-1 div.sk-label-container {text-align: center;}#sk-container-id-1 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-1 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-1" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>LinearRegression()</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-1" type="checkbox" checked><label for="sk-estimator-id-1" class="sk-toggleable__label sk-toggleable__label-arrow">LinearRegression</label><div class="sk-toggleable__content"><pre>LinearRegression()</pre></div></div></div></div></div>




```python
y_pred=model.predict(X_test)
print(y_pred)
```

    [ 4.83313221  7.4993589   5.64184185  7.12894612  3.7174894   8.70227189
      3.07327146  4.31700107  5.0125586   6.97930071  7.70938225  8.04302045
      8.70427993  6.87932332  3.76746175  5.55040448  5.09494066  7.0373275
      7.17158187  7.83106635  5.7607798   8.17300549  8.22255678  8.66018223
      3.9536928   5.04968422  6.86338169  7.35061625  4.94583651  7.2707126
     10.25961697  6.87374497  6.81616303  6.13102978  8.18742122  7.11086568
      7.06102491  7.17665392  6.80845574  5.09094347  7.78999704  4.92416636
      6.76622357  6.97221414  7.84005503  4.81323503  9.1099962   5.95707587
      5.00266281  7.94625394  6.99608445  5.98577103  4.0587513   5.1700882
      7.07068332  9.61277164  6.05355117  7.00352265  8.14521074  9.18197144
      4.03366076  5.04541234  6.30103516  7.17021072  5.97239349  4.9566522
      8.08781871  5.14843436  8.04561865  9.16488407  7.31512255  8.24304065
      4.86362017  4.95918213  4.2519008   6.96255573  5.0155015   8.48147541
      7.87440156  6.90712056  6.86882194  5.1261836   8.83521853  8.43517831
      7.68857988  4.85975105  6.91139189  5.08821832  7.9902922   6.2997241
      4.90626706  8.8670364   7.91671019  7.02144873  4.10634908  8.16668301
      5.12557201  5.63663337  7.24610703  3.57834412  4.74376999  2.91785774
      5.13817726  7.16507167  5.07355123  5.15304248  9.07173146  5.03007056
      9.58664493  5.1674238   7.42689267  4.97463743  5.35521982  7.12387407
      8.02541001  5.27578067  8.25452648  4.27355464  4.07924608  7.8717794
      7.42422471  6.88934304  8.90265141  7.20041531  7.26250649  7.47538825
      8.04424432  3.98737255  2.23433457  5.40086301  7.97630432  8.06039712
      4.10798589  6.93369593  7.01239651  8.82484981  3.69454041  7.46646212
      9.0813966   3.96428059  5.05772331]
    


```python
mse = mean_squared_error(y_test, y_pred)
print("MSE is:",mse)
```

    MSE is: 0.1634878354497829
    


```python
r2=r2_score(y_test,y_pred)
print("R2 score is:",r2)
```

    R2 score is: 0.9346646768397295
    


```python
comparison = pd.DataFrame({
    'Actual_Addicted_Score': y_test,
    'Predicted_Addicted_Score': y_pred
})

comparison.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Actual_Addicted_Score</th>
      <th>Predicted_Addicted_Score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>478</th>
      <td>5</td>
      <td>4.833132</td>
    </tr>
    <tr>
      <th>81</th>
      <td>7</td>
      <td>7.499359</td>
    </tr>
    <tr>
      <th>77</th>
      <td>5</td>
      <td>5.641842</td>
    </tr>
    <tr>
      <th>208</th>
      <td>7</td>
      <td>7.128946</td>
    </tr>
    <tr>
      <th>319</th>
      <td>4</td>
      <td>3.717489</td>
    </tr>
  </tbody>
</table>
</div>




```python
import matplotlib.pyplot as plt
top10 = (
    df.groupby('Country')['Addicted_Score']
      .mean()
      .sort_values(ascending=False)
      .head(10)
)
plt.figure(figsize=(10,6))
plt.barh(top10.index, top10.values)
plt.xlabel('Average Addiction Score')
plt.ylabel('Country')
plt.title('Top 10 Countries by Average Social Media Addiction Score')
plt.gca().invert_yaxis()  
for i, v in enumerate(top10.values):
    plt.text(v + 0.1, i, f"{v:.2f}", va='center')

plt.show()

```


    
![png](output_12_0.png)
    



```python
import matplotlib.pyplot as plt

plt.scatter(y_test, y_pred)
plt.xlabel('Actual Addiction Score')
plt.ylabel('Predicted Addiction Score')
plt.title('Actual vs Predicted Addiction Score')
plt.show()

```


    
![png](output_13_0.png)
    



```python

```
